<?php get_header(); ?>

<h1>This index is EMPTY, yo? Go to the <a href="?page_id=6">dash page</a>...</h1>

<?php get_footer(); ?>
