			<div class="push"></div>
        </div>
		<div class="footer bordertopgrey grid12col padtopsmall alignright jbasewrap">
            <span class="small">&copy; Sweetspot 2010</span>
		</div>
		<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js" type="text/javascript"></script>
		<script type="text/javascript" src="<?php bloginfo( 'template_url' ); ?>/property-dash/js/property-dash.js"></script>
	</body>
</html>