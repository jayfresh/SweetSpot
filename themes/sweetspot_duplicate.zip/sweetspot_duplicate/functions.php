<?php

add_theme_support( 'post-thumbnails' );
add_image_size( 'main-property-thumb', 250, 166, true );
add_image_size( 'property-gall-thumb', 200, 133, true ); 
add_image_size( 'property-image', 1024, 1024, true ); 


function attachment_toolbox($size = thumbnail, $type = 'house', $gallcount = '0', $ulClass = '', $emptyMsg = '') {

	$images = get_children(array(
		'post_parent'    => get_the_ID(),
		'post_type'      => 'attachment',
		'numberposts'    => -1, // show all
		'post_status'    => null,
		'post_mime_type' => 'image',
		'order'          => 'ASC',
		'orderby'        => 'menu_order',
	));			
	
	$count = 0;
	$out = '<ul class="'.$ulClass.'">';
	foreach($images as $image) {
		$attimg  = wp_get_attachment_image_src($image->ID,$size);
		$attimgurl = $attimg[0];
		$atturl   = wp_get_attachment_url($image->ID);
		$attlink  = get_attachment_link($image->ID);
		$postlink = get_permalink($image->post_parent);
		$atttitle = apply_filters('the_title',$image->post_title);
		$attcontent = $image->post_content;
		$attimgtype	= get_post_meta($image->ID,"_mySelectBox", true);
		$imglink	= $image->guid;

		if($attimgtype==$type) {
			$count++;
			$out .= '<li><a href='.$imglink.' rel="prettyPhoto[gallery'.$gallcount.']"><img class="primary" src="'.$attimgurl.'"/></a></li>';
		}
	}
	$out .= '</ul>';
	if($count>0) {	
		echo $out;
	} else {
		echo $emptyMsg;
	}
	return $count;
}

function attachment_selectbox_edit($form_fields, $post) {
	
	// select options: you could code these manually or get it from a database
	$select_options = array(
		"house" => "House",
		"floorplan" => "Floorplan",
	);

	// get the current value of our custom field
	$current_value = get_post_meta($post->ID, "_mySelectBox", true);
	
	// build the html for our select box
	$mySelectBoxHtml = "<select name='attachments[{$post->ID}][mySelectBox]' id='attachments[{$post->ID}][mySelectBox]'>";
	foreach($select_options as $value => $text){
	
		// if this value is the current_value we'll mark it selected
		$selected = ($current_value == $value) ? ' selected ' : '';
		
		// escape value	for single quotes so they won't break the html
		$value = addcslashes( $value, "'");
		
		$mySelectBoxHtml .= "<option value='{$value}' {$selected}>{$text}</option>";
	}
	$mySelectBoxHtml .= "</select>";
	
	// add our custom select box to the form_fields
	$form_fields["mySelectBox"]["label"] = __("Image Type");
	$form_fields["mySelectBox"]["input"] = "html";
	$form_fields["mySelectBox"]["html"] = $mySelectBoxHtml;

	return $form_fields;
}
add_filter("attachment_fields_to_edit", "attachment_selectbox_edit", null, 2);


function attachment_selectbox_save($post, $attachment) {
	if( isset($attachment['mySelectBox']) ){
		update_post_meta($post['ID'], '_mySelectBox', $attachment['mySelectBox']);
	}
	return $post;
}
add_filter("attachment_fields_to_save", "attachment_selectbox_save", null, 2);

/* supports notifications from PayPal */
/* assumes fields: ipn_txn_id, _property_status */
function inbox_save_post($vars) {
	require_once(ABSPATH . WPINC . '/registration.php');
	$payment_status = $vars['payment_status'];
	$IPN_reference = $vars['txn_id'];
	$IPN_address = $vars['item_number'];
	$IPN_payer_email = $vars['payer_email'];
	$IPN_payer_name = $vars['custom'];  // optional. JRL: should it be?
	$IPN_all = implode($vars,"~~");
	activity_log(array(
		'type'=>'notification',
		'entry'=>$IPN_all
	));
	if($IPN_reference and $IPN_address and $payment_status and $IPN_payer_email) {
		$loop = new WP_Query("post_type=properties"); // JRL: don't think I can just search by custom field (address)
		$property_matches=0;
		global $post;
		while ( $loop->have_posts() ) : $loop->the_post(); // JRL: I don't think looping through all the properties is going to be a good idea when there are lots of properties
			$address_field = get_post_meta($post->ID,"_address");
			$address_field = $address_field[0];
			if($address_field==$IPN_address) {
				$property_matches++;
				$the_ID = get_the_ID();
				if($payment_status=="Completed") {
					update_post_meta($the_ID, '_property_status', 'under_offer');
					add_post_meta($the_ID, 'ipn_txn_id', $IPN_reference, true) or update_post_meta($the_ID, 'ipn_txn_id', $IPN_reference);
					add_post_meta($the_ID, 'ipn_payer_email', $IPN_payer_email, true) or update_post_meta($the_ID, 'ipn_payer_email', $IPN_payer_email);
					echo "Payment acknowledged<br/>";
					// create account if necessary
					$user_id = username_exists( $IPN_payer_email );
					if ( !$user_id ) {
						if(!$IPN_payer_name) {
							$IPN_payer_name = $IPN_payer_email;
						}
						$random_password = wp_generate_password( 12, false );
						$user_id = wp_insert_user( array (
							'user_login' 	=> $IPN_payer_email, 
							'user_pass' 	=> $random_password, 
							'user_email' 	=> $IPN_payer_email,
							'display_name'	=> $IPN_payer_name,
							'role'			=> 'applicant'
							));
						echo "New account created for ".$IPN_payer_email.", ID: ".$user_id;
						wp_new_user_notification($user_id, $random_password);
					} else {
						echo "Account identified for ".$IPN_payer_email.", ID: ".$user_id;
					}
				} else if ($payment_status=="Refunded") {
					update_post_meta($the_ID, '_property_status', 'on_the_market');
					delete_post_meta($the_ID, 'ipn_txn_id');
					delete_post_meta($the_ID, 'ipn_payer_email');
					delete_post_meta($the_ID, 'ipn_all');
					echo "Refund processed";
				}
			}
		endwhile;
		if($property_matches==0) {
			echo "did not find any property matches for ".$IPN_address;
		}
	} else {
		echo "error: send at least 'txn_id', 'item_number', 'payment_status' and 'payer_email'";
	}
}

/* adds custom column to properties table view, so we can get to PayPal */
add_filter("manage_edit-properties_columns", "propertiesColumns");
function propertiesColumns($columns) {
	$columns['paypal'] = 'PayPal link';
	return $columns;
}
add_action("manage_posts_custom_column", "propertiesColumnsValue");
function propertiesColumnsValue($name) {
	global $post;
	if($name=='paypal') {
		$txn_id = get_post_meta($post->ID, "ipn_txn_id");
		if($txn_id[0]!="") {
			//echo $txn_id[0];
			echo makePayPalLink($txn_id[0]);
		} else {
			echo "no transactions";
		}
	}
}

function makePayPalLink($id) { // JRL: I want to make this link directly to the transaction or refund page, but I haven't figured out how to yet.
	return '<a href="https://www.paypal.com/uk/cgi-bin/webscr?cmd=_history">Reset for holding deposit transaction '.$id."</a>";
}

// adds properties reset panel to a Properties page 
add_action('admin_menu', 'add_properties_reset_box');
function add_properties_reset_box() {
	add_meta_box( 'properties_reset', 'properties Reset', 'display_reset_panel', 'properties');
}
function display_reset_panel() {
	global $post;
	$txn_id = get_post_meta($post->ID, "ipn_txn_id");
	echo "<p>Clicking the button below will take you to a page where you can refund a properties's holding deposit. Once the refund has completed, the property's status will be updated to 'on the market'.</p>";
	echo makePayPalLink($txn_id[0]);
}



// ************************************   commence special user-meta fields:


add_action( 'show_user_profile', 'my_show_extra_profile_fields' );
add_action( 'edit_user_profile', 'my_show_extra_profile_fields' );

function my_show_extra_profile_fields( $user ) { ?>

	<h3>Extra profile information</h3>

	<table class="form-table">

		<tr>
			<th><label for="phone">Phone Number</label></th>

			<td>
				<input type="text" name="user_phone" id="user_phone" value="<?php echo esc_attr( get_the_author_meta( 'user_phone', $user->ID ) ); ?>" class="regular-text" /><br />
				<span class="description">Please enter your phone number.</span>
			</td>
		</tr>

	</table>
<?php }

add_action( 'personal_options_update', 'my_save_extra_profile_fields' );
add_action( 'edit_user_profile_update', 'my_save_extra_profile_fields' );

function my_save_extra_profile_fields( $user_id ) {

	if ( !current_user_can( 'edit_user', $user_id ) )
		return false;

	/* Copy and paste this line for additional fields. Make sure to change 'user_phone' to the field ID. */
	update_usermeta( $user_id, 'user_phone', $_POST['user_phone'] );
}


// ************************************ create post type: Properties

if ( ! function_exists( 'post_type_properties' ) ) :

function post_type_properties() {

	register_post_type( 
		'properties',
		array( 
			'label' => __('Properties'), 
			'description' => __('Create a property.'), 
			'public' => true, 
			'show_ui' => true,
			'register_meta_box_cb' => 
                        'init_metaboxes_properties',
			'supports' => array (
				'title',
				'editor',
				'thumbnail',
				'excerpt',
				'custom-fields',
				'author'
				
			)
		)
	);

register_taxonomy( 'breeds', 'property-breeds', 
array ('hierarchical' => true, 'label' => __('Breeds'))); 

register_taxonomy( 'kittenmeta', 'property-meta', 
array ('hierarchical' => false, 'label' => __('Meta Keywords'),
'query_var' => 'propertymeta'));

}

endif;

add_action('init', 'post_type_properties');

// add custom fields to the custom post type here
$sp_boxes = array (
	'About the Property' => array (
		array( '_beds', 'Beds', 'Number of beds in this property'),
		array( '_baths', 'Baths', 'Number of baths in this property'),
		array( '_receptions', 'Receptions', 'Number of receptions in this property'),
		array( '_price', 'Price', 'Price per person per week'),
		array( '_period', 'Let Period', 'Length of let'),
		array( '_notes', 'Notes', 'Sales description of the property', 'textarea' ),
		array( '_mapnotes', 'Map Notes', 'Notes to go alongside the map', 'textarea' ),
		array( '_property_status', 'Property Status', '', 'select' ),
		
	),
	'Address' => array (
		array( '_address', 'Address', 'Property name / number &amp; street name', 'textarea' ),
		array( '_city', 'City / Town' ),
		array( '_postcode', 'Postcode' ),
		array( '_country', 'Country' ),
	)
);

// Do not edit past this point.

// Use the admin_menu action to define the custom boxes
//add_action( 'admin_menu', 'sp_add_custom_box' ); - not being used in place of the register_meta_box_cb above
function init_metaboxes_properties() {
	sp_add_custom_box();
}

// Adds a custom section to the "advanced" Post and Page edit screens
function sp_add_custom_box() {
	global $sp_boxes;
	if ( function_exists( 'add_meta_box' ) ) {
		foreach ( array_keys( $sp_boxes ) as $box_name ) {
			add_meta_box( $box_name, __( $box_name, 'sp' ), 'sp_post_custom_box', 'properties', 'normal', 'high' );
		}
	}
}

// this handles the nonces for the meta boxes
if ( ! function_exists( 'sp_post_custom_box' ) ) :
function sp_post_custom_box ($obj, $box) {
	global $sp_boxes;
	static $sp_nonce_flag = false;
	echo '<div style="width: 95%%; margin: 10px auto 10px auto; background-color: #F9F9F9; border: 1px solid #DFDFDF; -moz-border-radius: 5px; -webkit-border-radius: 5px; padding: 10px;">';
	// Run once
	if ( ! $sp_nonce_flag ) {
		echo_sp_nonce();
		$sp_nonce_flag = true;
	}
	// Generate box contents
	foreach ( $sp_boxes[$box['id']] as $sp_box ) {
		echo field_html( $sp_box );
	}
	echo '</div>';
}
endif;

// this switch statement specifies different types of meta boxes
// you can add more types if you add a case and a corresponding function
// to handle it
if ( ! function_exists( 'field_html' ) ) :
function field_html ( $args ) {
	switch ( $args[3] ) {
		case 'textarea':
			return text_area( $args );
		case 'checkbox':
			return sp_checkbox( $args );
		case 'select':
			return sp_select( $args );
		default:
			return text_field( $args );
	}
}
endif;

// this is the default text field meta box
if ( ! function_exists( 'text_field' ) ) :
function text_field ( $args ) {
	global $post;
	$description = $args[2];
	// adjust data
	$args[2] = get_post_meta($post->ID, $args[0], true);
	$args[1] = __($args[1], 'sp' );
	$label_format =
		'<div style="overflow:hidden;  margin-top:10px;">'.
		'<div style="width:100px; float:left;"><label for="%1$s"><strong>%2$s</strong></label></div>'.
		'<div style="width:500px; float:left;"><input style="width: 80%%;" type="text" name="%1$s" value="%3$s" />'.
		'<p style="clear:both"><em>'.$description.'</em><p></div>'.
		'</div>';
	return vsprintf( $label_format, $args );
}
endif;

// this is the text area meta box
if ( ! function_exists( 'text_area' ) ) :
function text_area ( $args ) {
	global $post;
	$description = $args[2];
	// adjust data
	$args[2] = get_post_meta($post->ID, $args[0], true);
	$args[1] = __($args[1], 'sp' );
	$label_format =
		'<div style="overflow:hidden; margin-top:10px; ">'.
		'<div style="width:100px; float:left;"><label for="%1$s"><strong>%2$s</strong></label></div>'.
		'<div style="width:500px; float:left;"><textarea style="width: 90%%;" name="%1$s">%3$s</textarea>'.
		'<p style="clear:both"><em>'.$description.'</em></p></div>'.
		'</div>';
	return vsprintf( $label_format, $args );
}
endif;

// this is the checkbox meta box
if ( ! function_exists( 'sp_checkbox' ) ) :
function sp_checkbox ( $args ) {
	global $post;
	$description = $args[2];
	// adjust data
	$args[2] = get_post_meta($post->ID, $args[0], true);
	$args[1] = __($args[1], 'sp' );
	$label_format =
		'<div style="width: 95%%; margin: 10px auto 10px auto; background-color: #F9F9F9; border: 1px solid #DFDFDF; -moz-border-radius: 5px; -webkit-border-radius: 5px; padding: 10px;">'.
		'<p><label for="%1$s"><strong>%2$s</strong></label></p>';
	$current_value = $args[2];
	$checked = ($current_value == "on") ? ' checked="checked"' : '';
	$label_format .= '<p><input type="checkbox" name="%1$s" '.$checked.' /></p>'.
		'<p><em>'.$description.'</em></p>'.
		'</div>';
	return vsprintf( $label_format, $args );
}
endif;

// this is the select meta box
if ( ! function_exists( 'sp_select' ) ) :
function sp_select ( $args ) {
	global $post;
	$description = $args[2];
	// adjust data
	$args[2] = get_post_meta($post->ID, $args[0], true);
	$args[1] = __($args[1], 'sp' );
	$label_format =
		'<div style="overflow:hidden; margin-top:10px; ">'.
		'<div style="width:100px; float:left;"><label for="%1$s"><strong>%2$s</strong></label></div>'.
		'<div style="width:500px; float:left;">'.
		'<select name="%1$s" id="%1$s">';
	
	$current_value = $args[2];
	$select_options = array( // JRL - we'll want to take this options definition out of this function and pop it up where people are setting up the metaboxes
		"on_the_market"=>"On the market",
		"under_offer"=>"Under offer",
		"let"=>"Let"
	);
	foreach($select_options as $value => $text){
	
		// if this value is the current_value we'll mark it selected
		
		$selected = ($current_value == $value) ? ' selected="selected"' : '';
		
		// escape value	for quotes so they won't break the html
		$value = addslashes($value);
		
		$label_format .= '<option value="'.$value.'"'.$selected.'>'.$text.'</option>';
	}
		
	$label_format .= '</select>'.
		'<p><em>'.$description.'</em></p></div>'.
		'</div>';
	return vsprintf( $label_format, $args );
}
endif;

/* When the post is saved, saves our custom data */
if ( ! function_exists( 'sp_save_postdata' ) ) :
function sp_save_postdata($post_id, $post) {
	global $sp_boxes;
	// verify this came from the our screen and with proper authorization,
	// because save_post can be triggered at other times
	if ( ! wp_verify_nonce( $_POST['sp_nonce_name'], plugin_basename(__FILE__) ) ) {
		return $post->ID;
	}
	// Is the user allowed to edit the post or page?
	if ( 'page' == $_POST['post_type'] ) {
		if ( ! current_user_can( 'edit_page', $post->ID ))
			return $post->ID;
		} else {
		if ( ! current_user_can( 'edit_post', $post->ID ))
			return $post->ID;
		}
		// OK, we're authenticated: we need to find and save the data
		// We'll put it into an array to make it easier to loop though.
		// The data is already in $sp_boxes, but we need to flatten it out.
		foreach ( $sp_boxes as $sp_box ) {
			foreach ( $sp_box as $sp_fields ) {
				$my_data[$sp_fields[0]] =  $_POST[$sp_fields[0]];
			}
		}
		// Add values of $my_data as custom fields
		// Let's cycle through the $my_data array!
		foreach ($my_data as $key => $value) {
			if ( 'revision' == $post->post_type  ) {
				// don't store custom data twice
				return;
			}
			// if $value is an array, make it a CSV (unlikely)
			$value = implode(',', (array)$value);
			if ( get_post_meta($post->ID, $key, FALSE) ) {
				// Custom field has a value.
				update_post_meta($post->ID, $key, $value);
			} else {
				// Custom field does not have a value.
				add_post_meta($post->ID, $key, $value);
		}
		if (!$value) {
			// delete blanks
			delete_post_meta($post->ID, $key);
		}
	}
}
endif;

if ( ! function_exists( 'echo_sp_nonce' ) ) :
function echo_sp_nonce () {
	// Use nonce for verification ... ONLY USE ONCE!
	echo sprintf(
		'<input type="hidden" name="%1$s" id="%1$s" value="%2$s" />',
		'sp_nonce_name',
		wp_create_nonce( plugin_basename(__FILE__) )
	);
}
endif;

// A simple function to get data stored in a custom field
if ( ! function_exists( 'get_custom_field' ) ) :
if ( !function_exists('get_custom_field') ) {
	function get_custom_field($field) {
		global $post;
		$custom_field = get_post_meta($post->ID, $field, true);
		echo $custom_field;
	}
}
endif;

// Use the save_post action to do something with the data entered
// Save the custom fields
add_action( 'save_post', 'sp_save_postdata', 1, 2 );


// ****************************************************************** Register Viewing Post type

if ( ! function_exists( 'post_type_viewings' ) ) :

function post_type_viewings() {

	register_post_type( 
		'viewings',
		array( 
			'label' => __('Viewings'), 
			'description' => __('Logging booked viewings.'), 
			'public' => true, 
			'show_ui' => true,
			'supports' => array (
				'title',
				'editor',
				'thumbnail',
				'excerpt',
				'custom-fields',
				'author'
			)
		)
	);
}

endif;

add_action('init', 'post_type_viewings');


// ************ creating new accounts when receiving new viewing booking ***********

 function processViewingBooking($vars) {
	require_once(ABSPATH . WPINC . '/registration.php');
	$username =  $vars['booked_by'];
	$useremail = $username;
	$address = $vars['address'];
	$datetime = $vars['booking_datetime'];
	$booked_by_name = $vars['booked_by_name']; // optional. JRL: should it be?
	if($username && $address && $datetime) {
		// create account if necessary
		$user_id = username_exists( $username );
		if ( !$user_id ) {
			if(!$booked_by_name) {
				$booked_by_name = $username;
			}
			$random_password = wp_generate_password( 12, false );
			$user_id = wp_insert_user( array (
				'user_login' 	=> $username, 
				'user_pass' 	=> $random_password, 
				'user_email' 	=> $useremail,
				'display_name'	=> $booked_by_name,
				'role'			=> 'applicant'
				));
			echo "New account created for ".$useremail.", ID: ".$user_id;
			wp_new_user_notification($user_id, $random_password);
		} else {
			echo "Account identified for ".$useremail.", ID: ".$user_id;
		}
		// store event
		$new_event = array();
		$new_event['post_title'] = time();
		$new_event['post_type'] = 'viewings';
		$new_event['post_content'] = 'This is my new viewing.';
		$new_event['post_status'] = 'publish';
		$new_event['post_author'] = $user_id;
		$event_id = wp_insert_post($new_event);
		if($event_id) {
			update_post_meta($event_id, "address", $address);
			update_post_meta($event_id, "datetime", $datetime);
		}
	} else {
		// fail silently
		$out = "please send booked_by, address and booking_datetime parameters. I found: ";
		foreach($vars as $key=>$value) {
			$out .= $key.": ".$value."; ";
		}
		echo $out;
	}
} 

// ************ end creating new accounts when receiving new viewing booking ************

?>