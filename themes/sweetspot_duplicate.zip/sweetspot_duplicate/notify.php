<?php 
/*

Template Name: post-notification

*/

$vars;
if($_POST) {
	$vars = $_POST;
} else {
	$vars = $_GET;
}
inbox_save_post($vars);

?>
