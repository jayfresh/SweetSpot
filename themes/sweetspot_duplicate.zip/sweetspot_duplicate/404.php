
<?php get_header() ?>
<div id="content"> 
		<div class="container"> 
			<div class="description"> 
				<br>
					<p>Oops! That Page doesn't exist! Please go <a href="http://www.test.sweetspot.com">home</a> and try another page.</p>
									
				<br> 
				<img src='../images/chair_2_blue.png' class='hero_floater' alt="chair"> 
			</div> 
			
		</div> 
	</div> 

	<?php get_footer(); ?>
